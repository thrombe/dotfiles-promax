// ==UserScript==
// @name     refactoring guru delete top animation bar
// @version  1
// @grant    none
// ==/UserScript==

document.querySelector("[data-id='DIDP-announcement']").remove();
